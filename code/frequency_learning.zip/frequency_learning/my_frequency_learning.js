/******************************************************************************/
/*** Preamble ************************************************/
/******************************************************************************/

/*
The experiment features two main trial types - observation (training) and production (test)
Observation: see object for 1 second, then object plus label for 2 seconds
Production: see object plus two labels, select label, confirm label choice to center cursor.
*/

/******************************************************************************/
/*** Initialise jspsych *******************************************************/
/******************************************************************************/

/*
As per last week, we will use the save_data function to save that data to the server_data folder on the
jspsychlearning server, in a file called "frequencylearning_data.csv".
*/


var jsPsych = initJsPsych({
  on_finish: function () {
    var all_data = jsPsych.data.get(); //get all data
    var all_data_as_csv = all_data.csv(); //convert to csv format
    save_data("frequencylearning_data.csv", all_data_as_csv); //save it using save_data function defined in utilities.js
  },
});

/******************************************************************************/
/*** Observation trials ************************************************/
/******************************************************************************/

// Your code for observation trials goes here

/******************************************************************************/
/*** Production trials ************************************************/
/******************************************************************************/

// Your code for production trials goes here

/******************************************************************************/
/*** Instruction trials *******************************************************/
/******************************************************************************/

/*
As usual, your experiment will need some instruction screens.
*/

var consent_screen = {
  type: jsPsychHtmlButtonResponse,
  stimulus:
    "<h3>Welcome to the experiment</h3> \
  <p style='text-align:left'>Experiments begin with an information sheet that explains to the participant \
  what they will be doing, how their data will be used, and how they will be \
  remunerated.</p> \
  <p style='text-align:left'>This is a placeholder for that information, which is normally reviewed \
  as part of the ethical review process.</p>",
  choices: ["Yes, I consent to participate"],
};

var instruction_screen_observation = {
  type: jsPsychHtmlButtonResponse,
  stimulus:
    "<h3>Observation Instructions</h3>\
  <p>You will observe one object being named several times. \
  Just sit back and watch.</p>",
  choices: ["Continue"],
};

var instruction_screen_production = {
  type: jsPsychHtmlButtonResponse,
  stimulus:
    "<h3>Production Instructions</h3>\
  <p>Next, you will be shown the same object again. \
  Please name this object like you saw in the observation stage. \
  This will repeat several times.</p>",
  choices: ["Continue"],
};

var final_screen = {
  type: jsPsychHtmlButtonResponse,
  stimulus:
    "<h3>Finished!</h3>\
  <p style='text-align:left; padding-left: 40px; padding-right: 40px'>\
  Experiments often end with a final screen, e.g. that contains a completion\
  code so the participant can claim their payment. Here we just finish on a\
  final button-response screen, so when you click continue the experiment will\
  end and your data will be saved.</p>",
  choices: ["Click to finish the experiment"],
};

/******************************************************************************/
/*** Build the timeline *******************************************************/
/******************************************************************************/

/*
I am using concat here to make sure the timeline is a flat list - depending on 
how you implement the production and observation trials, just doing
timeline=[consent_screen,instruction_screen_observation,observation_trials,...]
might produce something with a nested structure (e.g. if observation_trials is itself a
list) that jspsych can't handle.
*/
var full_timeline = [].concat(
  consent_screen,
  instruction_screen_observation,
  //put your observation trials here
  instruction_screen_production,
  //put your production trials here
  final_screen
);

/******************************************************************************/
/*** Run the timeline *******************************************************/
/******************************************************************************/

/*
Finally we call jsPsych.run to run the timeline we have created.
*/
jsPsych.run(full_timeline);
