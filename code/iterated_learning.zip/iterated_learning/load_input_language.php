<?php
declare(strict_types=1);

header('Access-Control-Allow-Origin: https://jspsychlearning.ppls.ed.ac.uk');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

// Reads a CSV file from /home/UUN/server_data/il/ready_to_iterate

$uun = 'ksmith7'; // Replace with your own UUN.
$maxFileBytes = 1_000_000;

function fail(int $status, string $message): void
{
    http_response_code($status);
    echo json_encode(['error' => $message]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST, OPTIONS');
    fail(405, 'Method not allowed');
}

if (!str_starts_with(
    strtolower($_SERVER['CONTENT_TYPE'] ?? ''),
    'application/json'
)) {
    fail(415, 'Content-Type must be application/json');
}

$raw = file_get_contents('php://input', false, null, 0, 10_001);

if ($raw === false || strlen($raw) > 10_000) {
    fail(413, 'Request body is too large');
}

try {
    $obj = json_decode($raw, true, 16, JSON_THROW_ON_ERROR);
} catch (JsonException $e) {
    fail(400, 'Invalid JSON');
}

if (!is_array($obj)
    || !isset($obj['filename'])
    || !is_string($obj['filename'])) {
    fail(400, 'filename must be a string');
}

$filename = $obj['filename'];

if (strlen($filename) > 100
    || !preg_match('/\A[A-Za-z0-9][A-Za-z0-9_-]{0,94}\.csv\z/D', $filename)
    || basename($filename) !== $filename) {
    fail(400, 'Invalid filename');
}

if (!preg_match('/\A[A-Za-z0-9][A-Za-z0-9_-]{0,99}\z/D', $uun)) {
    fail(500, 'Invalid server configuration');
}

$readyPath = '/home/' . $uun . '/server_data/il/ready_to_iterate';
$base = realpath($readyPath);

// Require the configured directory without symlinks in its path.
if ($base === false
    || $base !== $readyPath
    || !is_dir($base)
    || !is_readable($base)) {
    fail(500, 'Data directory is unavailable');
}

$path = $base . DIRECTORY_SEPARATOR . $filename;

if (is_link($path) || !is_file($path)) {
    fail(404, 'File not found');
}

// Read at most the configured limit plus one byte.
$filedata = @file_get_contents($path, false, null, 0, $maxFileBytes + 1);

if ($filedata === false) {
    error_log('Failed to read experiment CSV');
    fail(500, 'Failed to read file');
}

if (strlen($filedata) > $maxFileBytes) {
    fail(413, 'CSV file is too large');
}

// Remove an optional UTF-8 byte order mark before parsing the header.
if (str_starts_with($filedata, "\xEF\xBB\xBF")) {
    $filedata = substr($filedata, 3);
}

// Parse with fgetcsv so quoted commas and multiline fields work.
$stream = fopen('php://temp', 'w+');

if ($stream === false) {
    fail(500, 'Failed to process CSV');
}

if (fwrite($stream, $filedata) !== strlen($filedata)) {
    fclose($stream);
    fail(500, 'Failed to process CSV');
}

rewind($stream);

$headers = fgetcsv($stream, 0, ',', '"', '\\');

if ($headers === false
    || in_array(null, $headers, true)
    || in_array('', $headers, true)
    || count(array_unique($headers)) !== count($headers)) {
    fclose($stream);
    fail(500, 'CSV must have non-empty, unique column headers');
}

$csv = [];

while (($row = fgetcsv($stream, 0, ',', '"', '\\')) !== false) {
    // Ignore completely blank lines.
    if ($row === [null]) {
        continue;
    }

    if (count($row) !== count($headers)) {
        fclose($stream);
        fail(500, 'CSV row has an incorrect number of fields');
    }

    // Cast to object so even numeric column names produce JSON objects.
    $csv[] = (object) array_combine($headers, $row);
}

fclose($stream);

try {
    $response = json_encode($csv, JSON_THROW_ON_ERROR);
} catch (JsonException $e) {
    fail(500, 'CSV contains invalid UTF-8 data');
}

echo $response;