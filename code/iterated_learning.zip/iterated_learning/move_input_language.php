<?php
declare(strict_types=1);

header('Access-Control-Allow-Origin: https://jspsychlearning.ppls.ed.ac.uk');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

// moves files between sub-folders of /home/UUN/il/
// will only accept specified sub-folders: ready_to_iterate, undergoing_iteration, completed_iteration

$uun = 'ksmith7'; // Replace with your own UUN.

function fail(int $status, string $message): void
{
    http_response_code($status);
    echo json_encode(['error' => $message]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST, OPTIONS');
    fail(405, 'Method not allowed');
}

if (!str_starts_with(
    strtolower($_SERVER['CONTENT_TYPE'] ?? ''),
    'application/json'
)) {
    fail(415, 'Content-Type must be application/json');
}

$raw = file_get_contents('php://input', false, null, 0, 10_001);

if ($raw === false || strlen($raw) > 10_000) {
    fail(413, 'Request body is too large');
}

try {
    $obj = json_decode($raw, true, 16, JSON_THROW_ON_ERROR);
} catch (JsonException $e) {
    fail(400, 'Invalid JSON');
}

if (!is_array($obj)
    || !isset($obj['filename'], $obj['source'], $obj['destination'])
    || !is_string($obj['filename'])
    || !is_string($obj['source'])
    || !is_string($obj['destination'])) {
    fail(400, 'filename, source, destination must be strings');
}

$filename = $obj['filename'];
$source = $obj['source'];
$destination = $obj['destination'];

if (strlen($filename) > 100
    || !preg_match('/\A[A-Za-z0-9][A-Za-z0-9_-]{0,94}\.csv\z/D', $filename)
    || basename($filename) !== $filename) {
    fail(400, 'Invalid filename');
}

// Only these three movements are permitted.
$allowedMoves = [
    'ready_to_iterate' => ['undergoing_iteration'],
    'undergoing_iteration' => ['ready_to_iterate', 'completed_iteration'],
];

if (!array_key_exists($source, $allowedMoves)
    || !in_array($destination, $allowedMoves[$source], true)) {
    fail(400, 'Invalid movement');
}

if (!preg_match('/\A[A-Za-z0-9][A-Za-z0-9_-]{0,99}\z/D', $uun)) {
    fail(500, 'Invalid server configuration');
}

$rootDir = '/home/' . $uun . '/server_data/il';
$root = realpath($rootDir);

// Require the configured directory without symlinks in its path.
if ($root === false || $root !== $rootDir || !is_dir($root)) {
    fail(500, 'Data directory is unavailable');
}

$directories = [
    'ready_to_iterate' => $root . '/ready_to_iterate',
    'undergoing_iteration' => $root . '/undergoing_iteration',
    'completed_iteration' => $root . '/completed_iteration',
];

$sourceDir = $directories[$source];
$destinationDir = $directories[$destination];

foreach ([$sourceDir, $destinationDir] as $dir) {
    if (is_link($dir)
        || !is_dir($dir)
        || realpath($dir) !== $dir) {
        fail(500, 'Movement directory is unavailable');
    }
}

$sourcePath = $sourceDir . DIRECTORY_SEPARATOR . $filename;
$destinationPath = $destinationDir . DIRECTORY_SEPARATOR . $filename;

// All requests to this script share one lock.
// PHP must have permission to create this file in the il directory.
$lockPath = $root . '/.move_input_language.lock';

if (is_link($lockPath)
    || (file_exists($lockPath) && !is_file($lockPath))) {
    fail(500, 'Move lock is unavailable');
}

$lock = @fopen($lockPath, 'c');

if ($lock === false) {
    fail(500, 'Move lock is unavailable');
}

if (!flock($lock, LOCK_EX)) {
    fclose($lock);
    fail(500, 'Failed to acquire move lock');
}

try {
    clearstatcache();

    if (is_link($sourcePath) || !is_file($sourcePath)) {
        fail(404, 'Source file is unavailable');
    }

    // rename() normally overwrites files: explicitly prevent that.
    if (is_link($destinationPath) || file_exists($destinationPath)) {
        fail(409, 'Destination file already exists');
    }

    if (!@rename($sourcePath, $destinationPath)) {
        error_log('Failed to move experiment input file');
        fail(500, 'Failed to move file');
    }
} finally {
    flock($lock, LOCK_UN);
    fclose($lock);
}

echo json_encode(['status' => 'moved']);