/******************************************************************************/
/*** Code for saving csv-type data (save_data) ********************************/
/******************************************************************************/

// helps save_data to try again if data saving fails
async function fetch_with_retry(...args) {
  let count = 0;
  while(count < 3) {
      try {
      let response = await fetch(...args);
      if (response.status !== 200) {
          throw new Error("Didn't get 200 Success");
      }
      return response;
      } catch(error) {
      console.log(error);
      }
      count++;
      await new Promise(x => setTimeout(x, 250));
  }
  throw new Error("Too many retries");
}

/*
This is a modified version of our usual save_data function - we can specify one 
of a restricted set of sub-folders of server_data/il/ we want to save to. 
There are a list of possible directories specified in the PHP script:
"participant_data" -> il/participant_data
"ready_to_iterate" -> il/ready_to_iterate
""
*/
async function save_data_in_destination(destination,filename, data){
  var url = 'save_data_in_destination.php';
  var data_to_send = {
    destination: destination,
    filename: filename,
    filedata: data,
  };
  await fetch_with_retry(url, {
      method: 'POST',
      body: JSON.stringify(data_to_send),
      headers: new Headers({
              'Content-Type': 'application/json'
      })
  });
}


/******************************************************************************/
/*** Listing, reading and saving language files *******************************/
/******************************************************************************/

/*
We need various functions which call PHP scripts which interact with saved language
files - this is how we read in a previous participant's language to use as input,
and save the current participant's output language to use as input for others. 

Language files are simply CSV files with two names columns, object (giving the image
file) and label (giving the label for that object in the language).

Most of these functions as async, since there will be a short delay as we wait for the
PHP script to read/write files on the server.
*/

/*
list_input_languages() uses list_input_languages.php to return a list of files in
server_data/il/ready_to_iterate - these are candidate input languages which can be
used for iteration.
*/

async function list_input_languages() {
  var response = await fetch("list_input_languages.php");
  // various steps to convert the string returned by the PHP script into
  // something we can work with
  var text_response = await response.text();
  var object_response = JSON.parse(text_response);
  var language_file_list = Object.values(object_response);
  return language_file_list;
}

/*
Once we have selected an input language file, we need to read it in. This is handled
by load_input_language.php, which accesses files in server_data/il/ready_to_iterate and 
then uses Papa parse to convert the CSV contents to a format we can use.
*/

async function read_input_language(input_language_filename) {
  var data_to_send = { filename: input_language_filename }; 
  var response = await fetch("load_input_language.php", {
    method: "POST",
    body: JSON.stringify(data_to_send),
    headers: new Headers({
      "Content-Type": "application/json",
    }),
  });
  var input_language_as_text = await response.text();
  var input_language = JSON.parse(input_language_as_text);
  return input_language;
}


/*
At various points we need to move input language files around: we move the file from
ready_to_iterate to undergoing_iteration when a participant starts working on a
given file; we move the file back to ready_to_iterate if the participant abandons;
we move the file from undergoing_iteration to completed_iteration if they complete.
All of these are accomplished by move_input_language - we specify the file name,
the directory to move from, and the directory to move to, and move_input_language.php
does the moving for us.

Note that this function isn't async, because we don't actually need to wait for the
move to complete before we can proceed.
*/
function move_input_language(input_language_filename, from_folder, to_folder) {
  var data_to_send = {
    filename: input_language_filename,
    source: from_folder,
    destination: to_folder,
  };
  fetch("move_input_language.php", {
    method: "POST",
    body: JSON.stringify(data_to_send),
    headers: new Headers({
      "Content-Type": "application/json",
    }),
  });
}

/*
When a participant completes the production phase, we need to save the language they
produced in the final production test so that it can be used as input for another
learner.  save_output_language works through object_label_list, which is a list of
objects of the form {object:image_filename,label:'participant_label'} that is built
during the production phase of the experiment. save_output_language builds a
CSV string which can be directly saved to server_data/il/ready_to_iterate using the
normal save_data function. Output languages are saved to a file chainX_gY.csv where
X is the chain number and Y is the generation number.
*/

function save_output_language(chain,generation,object_label_list) {
  var output_string = "object,label\n"; //column headers plus a new line
  for (object_label_pair of object_label_list) {
    //for each object_label_pair
    //append object,label\n to the end of output_string
    output_string =
      output_string +
      object_label_pair.object +
      "," +
      object_label_pair.label +
      "\n";
  }
  //work put the filename using global variables chain and generation
  var output_file_name = "chain" + chain + "_g" + generation + ".csv";
  save_data_in_destination("ready_to_iterate", output_file_name, output_string);
}

/******************************************************************************/
/*** Utility functions for iteration ******************************************/
/******************************************************************************/

/*
The functions here move files around the sub-folders of server_data/il, allowing 
us to keep track of which chains are running, which are ready for new participants, 
and so on.
*/

/*
start_new_generation uses list_input_languages to check for available language 
files in il/ready_to_iterate.

If there are none, it returns status "no_chains_available"
If there are, it selects one at random and returns a dictionary specifying
chain number, generation number, and the input language
*/

async function start_new_generation() {
  var available_input_languages = await list_input_languages();
  console.log(available_input_languages); //console log them
  if (available_input_languages.length == 0) {
    return {status: "no_chains_available"}
  }
  else {
    // Select a random input language to use.
    var input_language_filename = jsPsych.randomization.shuffle(
      available_input_languages
    )[0];
    // The name of this file tells us what chain and generation we are running
    // To retrieve generation and chain info from filename, split the filename at _ and .
    var split_filename = input_language_filename.split(/_|\./);
    //chainX will be the first item in split_filename, just need to lop off the 'chain' prefix and convert to integer
    chain = parseInt(split_filename[0].substring(5));
    //gY will be the second item in split_filename, ust need to lop off the 'g' prefix and convert to integer
    var input_generation = parseInt(split_filename[1].substring(1));
    //*This* generation will be the input language generation + 1
    generation = input_generation + 1;

    // Next, we read in the input language from the appropriate file.
    var input_language = await read_input_language(input_language_filename);

    // And finally we move this input language file into il/undergoing_iteration, to prevent 
    // it being assigned to another participant.
    move_input_language(input_language_filename,
              "ready_to_iterate",
              "undergoing_iteration",
              );

  
    return {status: 'chain_selected',
      chain: chain,
      generation: generation,
      input_language_filename: input_language_filename,
      input_language: input_language
    }
  }
}


/*
complete_generation tidies up after a participant completes the final test: 
We save their output language into an appropriately-named file in il/ready_to_iterate.
We move their input language file from il/undergoing_iteration to il/completed_iteration.
*/

function complete_generation(chain,generation,input_language_filename,participant_final_label_set) {
  save_output_language(chain,generation,participant_final_label_set);
  move_input_language(input_language_filename,
          "undergoing_iteration",
          "completed_iteration"
        );
}


/* 
recycle is called if a participant abandons the experiment - we simply move the 
input_language_filename they were working on from il/undergoing_iteration back to il/ready_to_iterate
*/

function recycle(input_language_filename) {
    move_input_language(
      input_language_filename,
      "undergoing_iteration",
      "ready_to_iterate"
    )
}



