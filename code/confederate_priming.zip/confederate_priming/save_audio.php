<?php
declare(strict_types=1);

header('Access-Control-Allow-Origin: https://jspsychlearning.ppls.ed.ac.uk');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');

$userName = 'ksmith7'; //replace with your own UUN!
$dataDir = '/home/'.$userName.'/server_data'; 

// ffmpeg is installed centrally on jspsychlearning.
$ffmpeg = '/usr/local/bin/ffmpeg';
// Includes base64 and JSON overhead; increase for longer recordings.
$maxRequestBytes = 20_000_000;

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function fail(int $status, string $message): void
{
    http_response_code($status);
    echo json_encode(['error' => $message]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    fail(405, 'Method not allowed');
}
if (!str_starts_with(strtolower($_SERVER['CONTENT_TYPE'] ?? ''), 'application/json')) {
    fail(415, 'Content-Type must be application/json');
}
$raw = file_get_contents('php://input', false, null, 0, $maxRequestBytes + 1);
if ($raw === false || strlen($raw) > $maxRequestBytes) {
    fail(413, 'Request body is too large');
}
try {
    $obj = json_decode($raw, true, 16, JSON_THROW_ON_ERROR);
} catch (JsonException $e) {
    fail(400, 'Invalid JSON');
}
if (!is_array($obj)
    || !isset($obj['filename'], $obj['data'])
    || !is_string($obj['filename'])
    || !is_string($obj['data'])) {
    fail(400, 'filename, data must be strings');
}

$filename = $obj['filename'];
// Only audio output formats; no directories, shell syntax, or executable files.
$formats = [
    'wav' => 'wav', 'mp3' => 'mp3', 'ogg' => 'ogg', 'webm' => 'webm',
    'm4a' => 'ipod', 'flac' => 'flac', 'aac' => 'adts', 'opus' => 'opus',
    'mp4' => 'mp4',
];
if (strlen($filename) > 100
    || !preg_match('/\A[A-Za-z0-9][A-Za-z0-9_-]*\.(wav|mp3|ogg|webm|m4a|flac|aac|opus|mp4)\z/D', $filename)
    || basename($filename) !== $filename) {
    fail(400, 'Invalid filename');
}
$extension = pathinfo($filename, PATHINFO_EXTENSION);
$base = realpath($dataDir);
if ($base === false || !is_dir($base) || is_link($dataDir)) {
    fail(500, 'Data directory is unavailable');
}
$audioDir = $base . DIRECTORY_SEPARATOR . 'audio';
if (is_link($audioDir) || !is_dir($audioDir)
    || realpath($audioDir) !== $audioDir) {
    fail(500, 'Audio directory is unavailable');
}
$path = $audioDir . DIRECTORY_SEPARATOR . $filename;
if (is_link($path) || (file_exists($path) && !is_file($path))) {
    fail(400, 'Invalid destination');
}
$data = base64_decode($obj['data'], true);
if ($data === false || $data === '') {
    fail(400, 'data must contain non-empty base64-encoded audio');
}
if (!is_executable($ffmpeg)) {
    error_log('Audio converter is unavailable');
    fail(500, 'Failed to save audio');
}

// Use tempnam's actual file rather than appending .webm and leaving it behind.
$inputPath = tempnam(sys_get_temp_dir(), 'audio_');
$outputPath = tempnam($audioDir, 'audio_');
if ($inputPath === false || $outputPath === false) {
    if ($inputPath !== false) { @unlink($inputPath); }
    if ($outputPath !== false) { @unlink($outputPath); }
    fail(500, 'Failed to save audio');
}
$saved = false;
try {
    if (file_put_contents($inputPath, $data, LOCK_EX) === strlen($data)) {
        // Restrict input to browser audio containers and disable network access.
        // Explicit output format lets the temporary output have no extension.
        $cmd = escapeshellarg($ffmpeg)
            . ' -nostdin -hide_banner -loglevel error -y'
            . ' -protocol_whitelist file'
            . ' -format_whitelist matroska,webm,mov,ogg,wav'
            . ' -i ' . escapeshellarg($inputPath)
            . ' -vn -f ' . escapeshellarg($formats[$extension])
            . ' ' . escapeshellarg($outputPath) . ' 2>&1';
        $output = [];
        $exitCode = 1;
        exec($cmd, $output, $exitCode);
        if ($exitCode === 0 && filesize($outputPath) > 0) {
            // Publish only a completed conversion; retain overwrite behavior.
            // Allow the owner and the directory's group to read/write the recording.
            $saved = rename($outputPath, $path);
            // now use our special script to fix permissions
            $cmd = 'sudo /usr/local/bin/fix_server_data_permissions.sh '.$userName;
            shell_exec($cmd);
        }
    }
} finally {
    @unlink($inputPath);
    if (file_exists($outputPath)) { @unlink($outputPath); }
}
if (!$saved) {
    error_log('Failed to convert or save experiment audio');
    fail(500, 'Failed to save audio');
}
echo json_encode(['status' => 'saved']);
