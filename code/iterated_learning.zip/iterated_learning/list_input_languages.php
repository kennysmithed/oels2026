<?php
declare(strict_types=1);

header('Access-Control-Allow-Origin: https://jspsychlearning.ppls.ed.ac.uk');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

//lists files in /home/uun/server_data/il/ready_to_iterate

$uun = 'ksmith7'; // Replace with your own UUN.

function fail(int $status, string $message): void
{
    http_response_code($status);
    echo json_encode(['error' => $message]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET, OPTIONS');
    fail(405, 'Method not allowed');
}

if (!preg_match('/\A[A-Za-z0-9][A-Za-z0-9_-]{0,99}\z/D', $uun)) {
    fail(500, 'Invalid server configuration');
}

$readyPath = '/home/' . $uun . '/server_data/il/ready_to_iterate';
$base = realpath($readyPath);

// Require the exact configured directory, without symlinks in its path.
if ($base === false
    || $base !== $readyPath
    || !is_dir($base)
    || !is_readable($base)) {
    fail(500, 'Data directory is unavailable');
}

// Suppress filesystem warnings so server paths cannot leak into the response.
$entries = @scandir($base);

if ($entries === false) {
    error_log('Failed to list experiment data');
    fail(500, 'Failed to list files');
}

$contents = [];

foreach ($entries as $filename) {
    if (strlen($filename) > 100
        || !preg_match('/\A[A-Za-z0-9][A-Za-z0-9_-]{0,94}\.csv\z/D', $filename)) {
        continue;
    }

    $path = $base . DIRECTORY_SEPARATOR . $filename;

    if (is_link($path) || !is_file($path)) {
        continue;
    }

    $contents[] = $filename;
}

echo json_encode($contents);