/******************************************************************************/
/*** Preamble ************************************************/
/******************************************************************************/

/*
The experiment features 4 main trial types; the first two are used in the training phase, 
and the last two are used in the test phase:

- Guess-and-feedback trials: the participant sees an image and guesses the label, from a set of 4 options. 
They then see feedback showing the correct label.
- Reading trials: the participant sees an image and the correct label, but they don't have to respond.
- Multiple choice critical test trials: the participant sees an image and guesses the label, from a set of 4 options. 
There is no feedback.
- Cued recall critical test trials: the participant sees an image and a cue (e.g. "?-bridge") and types in the label.

*/

/******************************************************************************/
/*** Initialise jspsych *******************************************************/
/******************************************************************************/

/* 
In this week's lab we will start saving data to the server, so we'll stop
dumping it on screen at the end of the experiment. So our initialisation of jsPsych 
is very simple at the moment - in our implementation we'll show you how to save
data at the end.
*/

var jsPsych = initJsPsych({});

/******************************************************************************/
/*** Guess trials ************************************************/
/******************************************************************************/

/*
On a guess trial the participant sees an image and guesses the label, from a set 
of 4 options. 
*/

// YOUR IMPLEMENTATION OF GUESS TRIALS GOES HERE


/******************************************************************************/
/*** Reading trials ************************************************/
/******************************************************************************/

/*
These are very similar to the feedback part of the guess-and-feedback trials - the 
participant sees an image and the correct word, but they don't have to respond.
*/

// YOUR IMPLEMENTATION OF READING TRIALS GOES HERE

/******************************************************************************/
/*** Multiple choice critical tests *******************************************/
/******************************************************************************/

/*
These are very similar to the guess part of the guess-and-feedback trials - 
the participant sees an image and guesses the label, from a set, but there is no 
feedback. Note that in my implementation there are 4 multiple choice critical test 
trials, one for each of the 4 words learned in the training phase.
*/

// YOUR IMPLEMENTATION OF MULTIPLE CHOICE CRITICAL TESTS GOES HERE

/******************************************************************************/
/*** Cued recall critical trials **********************************************/
/******************************************************************************/

/* 
These are quite different from the other trial types - the participant sees an image 
and a cue (e.g. "?-bridge") and types in the label. 

We suggest you don't tackle this yourself (unless you are feeling ambitious!) - 
we will provide you with a working implementation of this trial type.
*/

//YOUR IMPLEMENTATION OF CUED RECALL CRITICAL TESTS WOULD GO HERE

/******************************************************************************/
/*** Instruction trials *******************************************************/
/******************************************************************************/

/*
As usual, your experiment will need some instruction screens.
*/

var consent_screen = {
  type: jsPsychHtmlButtonResponse,
  stimulus:
    "<h3>Welcome to the experiment</h3> \
  <p style='text-align:left; padding-left: 40px; padding-right: 40px'>\
  Experiments begin with an information sheet that explains to the participant \
  what they will be doing, how their data will be used, and how they will be \
  remunerated.</p> \
  <p style='text-align:left; padding-left: 40px; padding-right: 40px'>\
  This is a placeholder for that information, which is normally reviewed \
  as part of the ethical review process.</p>",
  choices: ["Yes, I consent to participate"],
};

var training_instruction_screen = {
  type: jsPsychHtmlButtonResponse,
  stimulus:
    "<h3>Instructions</h3>\
  <p style='text-align:left; padding-left: 40px; padding-right: 40px'>\
  First you will learn some Spanish words - we will show you images and \
  you either guess the Spanish word or read it.</p>",
  choices: ["Continue"],
};

var multiple_choice_instruction_screen = {
  type: jsPsychHtmlButtonResponse,
  stimulus:
    "<h3>Instructions</h3>\
  <p style='text-align:left; padding-left: 40px; padding-right: 40px'>\
  Now we will test your knowledge of the words you have learned - we will show you images and you \
  select the corresponding Spanish word.</p>",
  choices: ["Continue"],
};

var cued_recall_instruction_screen = {
  type: jsPsychHtmlButtonResponse,
  stimulus:
    "<h3>Instructions</h3>\
  <p style='text-align:left; padding-left: 40px; padding-right: 40px'>\
  Time for the final test - you will be shown images and asked to type in the corresponding Spanish word.</p>",
  choices: ["Continue"],
};

var final_screen = {
  type: jsPsychHtmlButtonResponse,
  stimulus:
    "<h3>Finished!</h3>\
  <p style='text-align:left; padding-left: 40px; padding-right: 40px'>\
  Experiments often end with a final screen, e.g. that contains a completion\
  code so the participant can claim their payment. Here we just finish on a\
  final button-response screen, so when you click continue the experiment will\
  end and your data will be saved.</p>",
  choices: ["Click to finish the experiment"],
};

/******************************************************************************/
/*** Build the timeline *******************************************************/
/******************************************************************************/

var full_timeline = [
  consent_screen,
  training_instruction_screen,
  // YOUR GUESS-AND-FEEDBACK AND READING TRIALS GO HERE
  multiple_choice_instruction_screen,
  // YOUR MULTIPLE CHOICE CRITICAL TESTS GO HERE
  cued_recall_instruction_screen,
  // YOUR CUED RECALL CRITICAL TESTS GO HERE
  final_screen,
];

/******************************************************************************/
/*** Run the timeline *******************************************************/
/******************************************************************************/

/*
Finally we call jsPsych.run to run the timeline we have created.
*/
jsPsych.run(full_timeline);
