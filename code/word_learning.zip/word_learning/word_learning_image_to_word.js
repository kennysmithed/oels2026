/******************************************************************************/
/*** Preamble ************************************************/
/******************************************************************************/

/*
The experiment features 4 main trial types:

- Guess-and-feedback trials: the participant sees an image and guesses the label, from a set of 4 options. 
They then see feedback showing the correct label.
- Reading trials: the participant sees an image and the correct label, but they don't have to respond.
- Multiple choice critical test trials: the participant sees an image and guesses the label, from a set of 4 options. 
There is no feedback.
- Cued recall critical test trials: the participant sees an image and a cue (e.g. "?-bridge") and types in the label.

*/

/******************************************************************************/
/*** Initialise jspsych *******************************************************/
/******************************************************************************/

/*
Rather than dumping all the data on-screen at the end of the experiment, we 
use the save_data function to save that data to the server_data folder on the
jspsychlearning server. In this case we will save it to a file called 
"wordlearning_data.csv".
*/

var jsPsych = initJsPsych({
  on_finish: function () {
    var all_data = jsPsych.data.get(); //get all data
    var all_data_as_csv = all_data.csv(); //convert to csv format
    save_data("wordlearning_data.csv", all_data_as_csv); //save it using save_data function defined in utilities.js
  },
});

/******************************************************************************/
/*** Guess trials ************************************************/
/******************************************************************************/

/*
On a guess trial the participant sees an image and guesses the label, from a set 
of 4 options. 
*/

var guess_truck_camion = {
  type: jsPsychImageButtonResponse,
  stimulus: "images/PICTURE_535.jpg", //this stimulus will be shown for every trial in the nested timeline
  timeline: [
    {
      //guessing trial - choose the word
      choices: ["camion", "le&oacute;n", "granja", "cepillar"],
      data: {
        //add some information to the data for this trial
        exp_trial_type: "guess", //mark this as a "guess" trial
        correct_word: "camion", //and record the correct word (for comparison with what the participant selects)
      },
      save_trial_parameters: { choices: true }, //we need to save the trial choices so we can score the trial on_finish
      on_finish: function (data) {
        //at the end of the trial...
        var button_number = data.response; //this is the *index* of the button they clicked
        var word_selected = data.choices[button_number]; //look up that button in choices to see what word they clicked
        data.response_word = word_selected; //record the word they clicked in the trial data
        //then score the trial by comparing the word they selected with the correct word
        if (word_selected == data.correct_word) {
          data.score = 1;
        } else {
          data.score = 0;
        }
      },
    },
    {
      //feedback trial - see the correct word, no response possible!
      prompt: "camion",
      choices: [],
      response_ends_trial: false,
      trial_duration: 5000,
      data: { exp_trial_type: "feedback" },
    },
  ],
};

var guess_key_llave = {
  type: jsPsychImageButtonResponse,
  stimulus: "images/PICTURE_78.jpg",
  timeline: [
    {
      //guessing trial - choose the word
      choices: ["pierna", "hormiga", "cuchara", "llave"],
      data: {
        exp_trial_type: "guess",
        correct_word: "llave",
      },
      save_trial_parameters: { choices: true },
      on_finish: function (data) {
        var button_number = data.response;
        var word_selected = data.choices[button_number];
        data.response_word = word_selected;
        if (word_selected == data.correct_word) {
          data.score = 1;
        } else {
          data.score = 0;
        }
      },
    },
    {
      //feedback trial - see the correct word, no response possible!
      prompt: "llave",
      choices: [],
      response_ends_trial: false,
      trial_duration: 5000,
      data: { exp_trial_type: "feedback" },
    },
  ],
};

/******************************************************************************/
/*** Reading trials ************************************************/
/******************************************************************************/

/*
These are very similar to the feedback part of the guess-and-feedback trials - the 
participant sees an image and the correct word, but they don't have to respond.
*/

var reading_ear_oreja = {
  type: jsPsychImageButtonResponse,
  stimulus: "images/PICTURE_35.jpg",
  prompt: "oreja",
  choices: [],
  response_ends_trial: false,
  trial_duration: 5000,
  data: { exp_trial_type: "reading", correct_word: "oreja" },
};

var reading_ball_pelota = {
  type: jsPsychImageButtonResponse,
  stimulus: "images/PICTURE_185.jpg",
  prompt: "pelota",
  choices: [],
  response_ends_trial: false,
  trial_duration: 5000,
  data: { exp_trial_type: "reading", correct_word: "pelota" },
};

/******************************************************************************/
/*** Multiple choice critical tests *******************************************/
/******************************************************************************/

/*
These are very similar to the guess part of the guess-and-feedback trials - 
the participant sees an image and guesses the label, from a set, but there is no 
feedback. Note that there are 4 multiple choice critical test trials, one for each 
of the 4 words learned in the training phase.
*/

var critical_test_mc_truck_camion = {
  type: jsPsychImageButtonResponse,
  stimulus: "images/PICTURE_535.jpg",
  choices: ["dedos", "camion", "altavoz", "arana"],
  data: {
    exp_trial_type: "critical_multiple_choice", //mark this as a "critical_multiple_choice" trial
    correct_word: "camion",
  },
  save_trial_parameters: { choices: true },
  on_finish: function (data) {
    var button_number = data.response;
    var word_selected = data.choices[button_number];
    data.response_word = word_selected;
    if (word_selected == data.correct_word) {
      data.score = 1;
    } else {
      data.score = 0;
    }
  },
};

var critical_test_mc_ear_oreja = {
  type: jsPsychImageButtonResponse,
  stimulus: "images/PICTURE_35.jpg",
  choices: ["oreja", "iceberg", "hada", "le&oacute;n"],
  data: {
    exp_trial_type: "critical_multiple_choice",
    correct_word: "oreja",
  },
  save_trial_parameters: { choices: true },
  on_finish: function (data) {
    var button_number = data.response;
    var word_selected = data.choices[button_number];
    data.response_word = word_selected;
    if (word_selected == data.correct_word) {
      data.score = 1;
    } else {
      data.score = 0;
    }
  },
};

var critical_test_mc_key_llave = {
  type: jsPsychImageButtonResponse,
  stimulus: "images/PICTURE_78.jpg",
  choices: ["hamburguesa", "rodilla", "llave", "maleta"],
  data: {
    exp_trial_type: "critical_multiple_choice",
    correct_word: "llave",
  },
  save_trial_parameters: { choices: true },
  on_finish: function (data) {
    var button_number = data.response;
    var word_selected = data.choices[button_number];
    data.response_word = word_selected;
    if (word_selected == data.correct_word) {
      data.score = 1;
    } else {
      data.score = 0;
    }
  },
};

var critical_test_mc_ball_pelota = {
  type: jsPsychImageButtonResponse,
  stimulus: "images/PICTURE_185.jpg",
  choices: ["pintura", "pelota", "incendio", "silla"],
  data: {
    exp_trial_type: "critical_multiple_choice",
    correct_word: "pelota",
  },
  save_trial_parameters: { choices: true },
  on_finish: function (data) {
    var button_number = data.response;
    var word_selected = data.choices[button_number];
    data.response_word = word_selected;
    if (word_selected == data.correct_word) {
      data.score = 1;
    } else {
      data.score = 0;
    }
  },
};

/******************************************************************************/
/*** Cued recall critical trials **********************************************/
/******************************************************************************/

/* 
These are quite different from the other trial types - the participant sees an image 
and a cue (e.g. "?-bridge") and types in the label. 

We achieve this using the jsPsychSurveyText plugin, which allows us to present a text input box for the 
participant to type their response. That plugin is constructed such that the text-box 
appears after the prompt, so we can use the prompt to show the image and the cue, 
and then the text box will appear below that. Because prompts are HTML, we can use an 
<img> tag to show the image, and then a <p> tag to show the text cue below.

The survey-text plugin is designed to allow multiple questions to be asked in a single trial, 
but we only want one question per trial here, so we just give it a single question in the questions array. 
The plugin will return the participant's response in an object with a key for each question (Q0, Q1, etc.), 
so we can use on_finish to copy the response for Q0 into a new variable called 
response_word in the trial data.
*/

var critical_test_cr_truck_camion = {
  type: jsPsychSurveyText,
  questions: [
    {
      //complex prompt - image and text cue
      prompt:
        "<img src='images/PICTURE_535.jpg'>\
      <p>?-truck</p>",
    },
  ],
  data: {
    exp_trial_type: "critical_cued_recall", //mark this as a "critical_cued_recall" trial
    correct_word: "camion",
  },
  on_finish: function (data) {
    var word_typed = data.response.Q0; //dig out the participant's response 
    data.response_word = word_typed; //add it to trial data
    //then score the trial by comparing the word they typed with the correct word, as before
    if (word_typed == data.correct_word) {
      data.score = 1;
    } else {
      data.score = 0;
    }
  },
};

var critical_test_cr_ear_oreja = {
  type: jsPsychSurveyText,
  questions: [
    {
      prompt:
        "<img src='images/PICTURE_35.jpg'>\
      <p>?-ear</p>",
    },
  ],
  data: {
    exp_trial_type: "critical_cued_recall",
    correct_word: "oreja",
  },
  on_finish: function (data) {
    var word_typed = data.response.Q0;
    data.response_word = word_typed;
    if (word_typed == data.correct_word) {
      data.score = 1;
    } else {
      data.score = 0;
    }
  },
};

var critical_test_cr_key_llave = {
  type: jsPsychSurveyText,
  questions: [
    {
      prompt:
        "<img src='images/PICTURE_78.jpg'>\
      <p>?-key</p>",
    },
  ],
  data: {
    exp_trial_type: "critical_cued_recall",
    correct_word: "llave",
  },
  on_finish: function (data) {
    var word_typed = data.response.Q0;
    data.response_word = word_typed;
    if (word_typed == data.correct_word) {
      data.score = 1;
    } else {
      data.score = 0;
    }
  },
};

var critical_test_cr_ball_pelota = {
  type: jsPsychSurveyText,
  questions: [
    {
      prompt:
        "<img src='images/PICTURE_185.jpg'>\
      <p>?-ball</p>",
    },
  ],
  data: {
    exp_trial_type: "critical_cued_recall",
    correct_word: "pelota",
  },
  on_finish: function (data) {
    var word_typed = data.response.Q0;
    data.response_word = word_typed;
    if (word_typed == data.correct_word) {
      data.score = 1;
    } else {
      data.score = 0;
    }
  },
};

/******************************************************************************/
/*** Instruction trials *******************************************************/
/******************************************************************************/

/*
As usual, your experiment will need some instruction screens.
*/

var consent_screen = {
  type: jsPsychHtmlButtonResponse,
  stimulus:
    "<h3>Welcome to the experiment</h3> \
  <p style='text-align:left; padding-left: 40px; padding-right: 40px'>\
  Experiments begin with an information sheet that explains to the participant \
  what they will be doing, how their data will be used, and how they will be \
  remunerated.</p> \
  <p style='text-align:left; padding-left: 40px; padding-right: 40px'>\
  This is a placeholder for that information, which is normally reviewed \
  as part of the ethical review process.</p>",
  choices: ["Yes, I consent to participate"],
};

var training_instruction_screen = {
  type: jsPsychHtmlButtonResponse,
  stimulus:
    "<h3>Instructions</h3>\
  <p style='text-align:left; padding-left: 40px; padding-right: 40px'>\
  First you will learn some Spanish words - we will show you images and \
  you either guess the Spanish word or read it.</p>",
  choices: ["Continue"],
};

var multiple_choice_instruction_screen = {
  type: jsPsychHtmlButtonResponse,
  stimulus:
    "<h3>Instructions</h3>\
  <p style='text-align:left; padding-left: 40px; padding-right: 40px'>\
  Now we will test your knowledge of the words you have learned - we will show you images and you \
  select the corresponding Spanish word.</p>",
  choices: ["Continue"],
};

var cued_recall_instruction_screen = {
  type: jsPsychHtmlButtonResponse,
  stimulus:
    "<h3>Instructions</h3>\
  <p style='text-align:left; padding-left: 40px; padding-right: 40px'>\
  Time for the final test - you will be shown images and asked to type in the corresponding Spanish word.</p>",
  choices: ["Continue"],
};

var final_screen = {
  type: jsPsychHtmlButtonResponse,
  stimulus:
    "<h3>Finished!</h3>\
  <p style='text-align:left; padding-left: 40px; padding-right: 40px'>\
  Experiments often end with a final screen, e.g. that contains a completion\
  code so the participant can claim their payment. Here we just finish on a\
  final button-response screen, so when you click continue the experiment will\
  end and your data will be saved.</p>",
  choices: ["Click to finish the experiment"],
};

/******************************************************************************/
/*** Build the timeline *******************************************************/
/******************************************************************************/

var full_timeline = [
  consent_screen,
  training_instruction_screen,
  guess_truck_camion,
  reading_ear_oreja,
  reading_ball_pelota,
  guess_key_llave,
  multiple_choice_instruction_screen,
  critical_test_mc_ear_oreja,
  critical_test_mc_truck_camion,
  critical_test_mc_key_llave,
  critical_test_mc_ball_pelota,
  cued_recall_instruction_screen,
  critical_test_cr_truck_camion,
  critical_test_cr_ear_oreja,
  critical_test_cr_key_llave,
  critical_test_cr_ball_pelota,
  final_screen,
];

/******************************************************************************/
/*** Run the timeline *******************************************************/
/******************************************************************************/

/*
Finally we call jsPsych.run to run the timeline we have created.
*/
jsPsych.run(full_timeline);
